jQuery(document).ready(function($) {
    'use strict';

    $( '.amp-color-picker' ).wpColorPicker();
    
});

